"""Evaluation function tests."""
